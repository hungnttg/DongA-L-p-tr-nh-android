package com.hungnq40.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.hungnq40.myapplication.R;
public class Demo21MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main);
    }

    @Override
    protected void onStart() {
        Log.d("onStart","Ham onStart duoc goi");
        super.onStart();
    }

    @Override
    protected void onStop() {
        Log.d("onStop","Ham onStop duoc goi");
        super.onStop();
    }

    @Override
    protected void onPause() {
        Log.d("onPause","Ham onPause duoc goi");
        super.onPause();
    }

    @Override
    protected void onResume() {
        Log.d("onResume","Ham onResume duoc goi");
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        Log.d("onDestroy","Ham onDestroy duoc goi");
        super.onDestroy();
    }
}