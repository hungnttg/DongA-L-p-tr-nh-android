package com.hungnq40.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Khai bao 3 doi tuong giao dien
    Button btnCong,btnTru,btnNhan;
    EditText txt1,txt2;
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCong=findViewById(R.id.btnCong);
        btnTru=findViewById(R.id.btnTru);
        btnNhan=findViewById(R.id.btnNhan);
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);
        tvKQ=findViewById(R.id.tvKetQua);
        //-- xu ly su kien
        btnCong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double so1 = Double.parseDouble(txt1.getText().toString());//chuyen doi text sang so
                double so2= Double.parseDouble(txt2.getText().toString());//chuyen doi text sang so
                double tong=so1+so2;
                tvKQ.setText(String.valueOf(tong));//dua vao ket qua
            }
        });
        btnTru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double so1 = Double.parseDouble(txt1.getText().toString());//chuyen doi text sang so
                double so2= Double.parseDouble(txt2.getText().toString());//chuyen doi text sang so
                double tong=so1-so2;
                tvKQ.setText(String.valueOf(tong));//dua vao ket qua
            }
        });
    }
}