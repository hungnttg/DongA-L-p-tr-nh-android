package com.hungnq40.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo22MainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main);
        txt1=findViewById(R.id.demo22txt1);
        txt2=findViewById(R.id.demo22txt2);
        btn1=findViewById(R.id.demo22Btn1);
        tvKQ=findViewById(R.id.demo22TvKQ);
        //xy ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TinhTong();
            }
        });
    }
    //dinh nghia ham tinh tong
   public void TinhTong()
    {
        //lay du lieu nguoi dung nhap va chuyen sang so
        double so1=Double.parseDouble(txt1.getText().toString());
        double so2=Double.parseDouble(txt2.getText().toString());
        //tinh tong
        double tong=so1+so2;
        //dua ket qua len textview
        tvKQ.setText(String.valueOf(tong));

    }
}