package com.hungnq40.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo32DetailMainActivity extends AppCompatActivity {
    TextView tvKQ;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_detail_main);
        tvKQ=findViewById(R.id.demo33DetailTvKQ);
        Intent intent=getIntent();//lay du lieu chuyen den
        int a=intent.getIntExtra("hsa",0);//boc tach he so a
        int b=intent.getIntExtra("hsb",0);//boc tach he so b
        int c=intent.getIntExtra("hsc",0);//boc tach he so c
        float detta=b*b-4*a*c;
        if(detta<0)
        {
            tvKQ.setText("PT vo nghiem");
        }
        else if(detta==0)
        {
            float x=-b/(2*a);
            tvKQ.setText("Nghiem pt la: "+x);
        }
        else
        {
            float x1= (float)(-b+Math.sqrt(detta))/(2*a);
            float x2=(float) (-b-Math.sqrt(detta))/(2*a);
            tvKQ.setText("PT co 2 nghiem x1="+x1+" va x2="+x2);
        }
    }
}