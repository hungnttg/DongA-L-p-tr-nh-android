package com.hungnq40.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hungnq40.myapplication.R;
public class Demo32MainActivity extends AppCompatActivity {
    EditText txtA,txtB,txtC;
    Button btnGPT;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main);
        txtA=findViewById(R.id.demo33Txta);
        txtB=findViewById(R.id.demo33Txtb);
        txtC=findViewById(R.id.demo33Txtbc);
        btnGPT=findViewById(R.id.demo33Btn);
        btnGPT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layVeCacHeSo();
            }
        });
    }

    private void layVeCacHeSo() {
        //lat ve 3 he so
        int a=Integer.parseInt(txtA.getText().toString());
        int b=Integer.parseInt(txtB.getText().toString());
        int c=Integer.parseInt(txtC.getText().toString());
        //tao intent chuyen du lieu
        Intent intent=new Intent(Demo32MainActivity.this,
                Demo32DetailMainActivity.class);
        //dua du lieu vao intent
        intent.putExtra("hsa",a);
        intent.putExtra("hsb",b);
        intent.putExtra("hsc",c);
        //chuyen qua detail
        startActivity(intent);
    }
}