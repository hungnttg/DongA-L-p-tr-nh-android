package com.hungnq40.myapplication.demo3_buoi5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hungnq40.myapplication.R;
public class Demo3B5MainActivity extends AppCompatActivity {
    ListView listView;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3_b5_main);
        listView=findViewById(R.id.demo3b5Listview);
        getDataToListview();
    }

    private void getDataToListview() {
        //Dinh nghia nguon du lieu
        String[] arr=new String[]{"Lap trinh java 1",
        "Lap trinh android co ban",
        "Lap trinh Javascript",
        "Lap trinh .net",
        "Lap trinh C++"};
        //tao adapter va gan du lieu voi adapter
        ArrayAdapter<String> arrayAdapter
                =new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arr);
        //dua du lieu len listview
        listView.setAdapter(arrayAdapter);
    }
}