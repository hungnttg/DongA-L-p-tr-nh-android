package com.hungnq40.myapplication.bai2n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo21nDetailMainActivity extends AppCompatActivity {
    TextView textView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21n_detail_main);
        setTitle("Activity 2");
        textView=findViewById(R.id.demo21nKetQua);
        //lay du lieu tu Activity A chuyen den
        Intent intent=getIntent();
        //boc tach tung phan
        double s1=intent.getDoubleExtra("so1",0);
        double s2=intent.getDoubleExtra("so2",0);
        //tinh tong
        double t=s1+s2;
        //hien thi ket qua
        textView.setText(String.valueOf(t));

    }
}