package com.hungnq40.myapplication.bai2n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo21nMainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21n_main);
        //anh xa
        txt1=findViewById(R.id.demo21nTxt1);
        txt2=findViewById(R.id.demo21nTxt2);
        btn1=findViewById(R.id.demo21nBtn1);
        tv1=findViewById(R.id.demo21nTvKQ);
        //xu ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //tao intent moi tu A den B
                Intent intent=new Intent(Demo21nMainActivity.this,
                        Demo21nDetailMainActivity.class);
                //Đưa dữ liệu vao intent
                intent.putExtra("so1",Double.parseDouble(txt1.getText().toString()));
                intent.putExtra("so2",Double.parseDouble(txt2.getText().toString()));
                //chuyen intent qua activity B
                startActivity(intent);
            }
        });
    }

}