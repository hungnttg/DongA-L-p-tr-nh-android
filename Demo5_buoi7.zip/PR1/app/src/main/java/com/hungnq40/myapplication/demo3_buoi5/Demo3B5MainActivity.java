package com.hungnq40.myapplication.demo3_buoi5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hungnq40.myapplication.R;
public class Demo3B5MainActivity extends AppCompatActivity {
    ListView listView;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3_b5_main);
        listView=findViewById(R.id.demo3B5Listview);
        docDuLieuVaHienThiLenListview();
    }

    private void docDuLieuVaHienThiLenListview() {
        //b1- Dinh nghia nguon du lieu
        String[] arr=new String[]{
                "Lap trinh co ban",
                "Lap trinh android",
                "Lap trinh .net",
                "Lap trinh PHP",
                "Lap trinh Python",
                "Thieets ke hinh anh voi photoshop",
                "Cong cu thiet ke va ve do hoa",
        };
        //b2- Gan adapter vao nguon du lieu
        //arrayAdaper(ngu canh, layout, nguon du lieu
        ArrayAdapter<String> arrayAdapter
                =new ArrayAdapter<>(context, android.R.layout.simple_list_item_1,arr);
        //B3- Ket noi adapter voi AdapterView
        listView.setAdapter(arrayAdapter);
    }

}