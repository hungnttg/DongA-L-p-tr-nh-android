package com.hungnq40.myapplication.demo3n;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hungnq40.myapplication.R;
public class Demo32MainActivity extends AppCompatActivity {
    EditText txtA,txtB,txtC;
    Button btnGiai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        txtA=findViewById(R.id.demo32nTxtA);
        txtB=findViewById(R.id.demo32nTxtB);
        txtC=findViewById(R.id.demo32nTxtC);
        btnGiai=findViewById(R.id.demo32BtnGiai);
        btnGiai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
            }
        });

    }

    private void getData() {
        //lay du lieu nguoi dung nhap
        int a= Integer.parseInt(txtA.getText().toString());
        int b=Integer.parseInt(txtB.getText().toString());
        int c=Integer.parseInt(txtC.getText().toString());
        //dua du lieu vao intent
        Intent intent=new Intent(Demo32MainActivity.this,
                Demo3n2SecondMainActivity.class);
        intent.putExtra("hsa",a);
        intent.putExtra("hsb",b);
        intent.putExtra("hsc",c);
        //chuyen du lieu sang detail
        startActivity(intent);
    }
}