package com.hungnq40.myapplication.demo3n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hungnq40.myapplication.R;
public class Demo3n1MainActivity extends AppCompatActivity {
    Button btnLogin,btnCancel;
    EditText txtU,txtP;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3n1_main);
        //anh xa
        txtU=findViewById(R.id.demo31nTxtU);
        txtP=findViewById(R.id.demo31nTxtP);
        btnLogin=findViewById(R.id.demo31nBtnLogin);
        //xu ly su kien
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dangNhap();
            }
        });

    }

    private void dangNhap() {
        //lay du lieu nguoi dung nhap
        String u=txtU.getText().toString();
        String p=txtP.getText().toString();
        if(u.equals("admin")&& p.equals("123456"))
        {
            //dua ra thong bao: MessageBox.show
            Toast.makeText(getApplicationContext(),"Dang nhap thanh cong",
                    Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Dang nhap that bai",
                    Toast.LENGTH_LONG).show();
        }
    }
}