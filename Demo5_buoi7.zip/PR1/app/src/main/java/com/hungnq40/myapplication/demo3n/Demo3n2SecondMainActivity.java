package com.hungnq40.myapplication.demo3n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.hungnq40.myapplication.R;
public class Demo3n2SecondMainActivity extends AppCompatActivity {
    TextView tvKQ;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3n2_second_main);
        tvKQ=findViewById(R.id.demo3n2TvKQ);
        //Lay du lieu tu main chuyen den
        Intent intent=getIntent();
        //boc tach du lieu
        int a=intent.getIntExtra("hsa",0);
        int b=intent.getIntExtra("hsb",0);
        int c=intent.getIntExtra("hsc",0);
        //giai
        float delta= b*b-4*a*c;
        if(delta<0)
        {
            tvKQ.setText("PT vo nghiem");
        }
        else if(delta==0)
        {
            float x=-b/(2*a);
            tvKQ.setText("PT co nghiem kep: "+x);
        }
        else
        {
            float x1= (float) (-b+Math.sqrt(delta)/(2*a));
            float x2= (float) (-b-Math.sqrt(delta)/(2*a));
            tvKQ.setText("Co 2 nghiem x1="+x1+"; va x2="+x2);
        }
    }
}