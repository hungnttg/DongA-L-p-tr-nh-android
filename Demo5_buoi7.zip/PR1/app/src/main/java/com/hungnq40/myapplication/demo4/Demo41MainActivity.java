package com.hungnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo41MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main);
        listView=findViewById(R.id.demo41Listview);
        //tao nguon du lieu
        List<Contact> arr=new ArrayList<>();
        arr.add(new Contact(Color.RED,"Nguyen Van an","0912345678"));
        arr.add(new Contact(Color.BLUE,"Tran Van Binh","0912345678"));
        arr.add(new Contact(Color.GRAY,"Vu Van Conhg","0912345678"));
        arr.add(new Contact(Color.GREEN,"Duong Thi Bich","0912345678"));
        arr.add(new Contact(Color.YELLOW,"Ly Van an","0912345678"));
        arr.add(new Contact(Color.RED,"Tran Van an","0912345678"));
        Deno41CustomAdapter adapter=new Deno41CustomAdapter(this,
                R.layout.demo41_item_layout,arr);
        listView.setAdapter(adapter);
    }
}