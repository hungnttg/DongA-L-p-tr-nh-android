package com.hungnq40.myapplication.demo4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hungnq40.myapplication.R;

import java.util.List;

public class Deno41CustomAdapter extends ArrayAdapter<Contact> {
    private Context context;
    private int resource;
    private List<Contact> lsContact;
    private LayoutInflater inflater;//doi tuong sinh layout dong
    public Deno41CustomAdapter(Context context, int resource,List<Contact> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.lsContact=objects;
        //khoi tao layout
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    //tao view
    //do du lieu vao view
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //Anh xa viewHolder
        ViewHolder1 holder=new ViewHolder1();
        if(convertView==null)//neu chua ton tai view thi tao view moi
        {
            convertView=inflater.inflate(R.layout.demo41_item_layout,null);//anh layout
            holder.tvColor=convertView.findViewById(R.id.demo41TvColor);//anh xa tung phan layout
            holder.tvName=convertView.findViewById(R.id.demo41TvName);//anh xa tung phan layout
            holder.tvPhone=convertView.findViewById(R.id.demo41TvPhone);//anh xa tung phan layout
            convertView.setTag(holder);//tao template de lan sau su dung
        }
        else //neu da ton tai view thi lay ra su dung
        {
            holder=(ViewHolder1) convertView.getTag();
        }
        //do du lieu vao view
        Contact contact=lsContact.get(position);
        holder.tvColor.setText(String.valueOf(position));
        holder.tvColor.setBackgroundColor(contact.getColor());
        holder.tvName.setText(contact.getName());
        holder.tvPhone.setText(contact.getPhone());
        return convertView;
    }

    //Dinh nghia (Lop anh xa voi layout item_view)
    public class ViewHolder1{
        TextView tvColor,tvName,tvPhone;
    }
}
