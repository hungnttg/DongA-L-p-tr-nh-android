package com.hungnq40.myapplication.demo4n;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hungnq40.myapplication.R;

import java.util.List;

public class Demo41mCustomAdapter extends ArrayAdapter<Demo4nContact> {
    private Context context;
    private int resource;
    private List<Demo4nContact> ls;
    private LayoutInflater inflater;//dich vu tao layout cua Android
    //ham khoi tao
    public Demo41mCustomAdapter(Context context, int resource, List<Demo4nContact> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.ls=objects;
        //khoi tao layout trong
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //-tao view
    // - va gan du lieu cho view

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //1. tao view
        Demo4n1ViewHolder viewHolder=new Demo4n1ViewHolder();
        if(convertView==null)//neu chua ton tai view thi tao view moi
        {
            convertView=inflater.inflate(R.layout.demo4n1_item_view,null);//generate layout
            //anh xa tung truong du lieu
            viewHolder.tvColor=convertView.findViewById(R.id.demo41nTvColor);
            viewHolder.tvName=convertView.findViewById(R.id.demo41nTvName);
            viewHolder.tvPhone=convertView.findViewById(R.id.demo41nTvPhone);
            //tao 1 template de lan sau su dung
            convertView.setTag(viewHolder);
        }
        else //truong hop da co view -> layview ve qua template
        {
            viewHolder=(Demo4n1ViewHolder) convertView.getTag();
        }
        //2. gan du lieu cho view
        Demo4nContact contact=ls.get(position);
        viewHolder.tvColor.setText(String.valueOf(position));
        viewHolder.tvColor.setBackgroundColor(contact.getColor());
        viewHolder.tvName.setText(contact.getName());
        viewHolder.tvPhone.setText(contact.getPhone());
        return convertView;
    }

    //Tao lop anh xa voi Item_layout
    public class Demo4n1ViewHolder{
        TextView tvColor,tvName,tvPhone;
    }
}
