package com.hungnq40.myapplication.demo4n;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo4n1MainActivity extends AppCompatActivity {
    ListView listView;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo4n1_main);
        listView=findViewById(R.id.demo41nListview);
        List<Demo4nContact> list=new ArrayList<>();
        list.add(new Demo4nContact(Color.RED,"Nguyen BVan An","0912345678"));
        list.add(new Demo4nContact(Color.BLUE,"Tran BVan Ben","0912345679"));
        list.add(new Demo4nContact(Color.GREEN,"Vu BVan Cong","0912345673"));
        list.add(new Demo4nContact(Color.YELLOW,"Ly BVan Dung","091234511"));
        list.add(new Demo4nContact(Color.GRAY,"Ho BVan Giang","0912345622"));
        list.add(new Demo4nContact(Color.RED,"Nguyen BVan An","0912345644"));
        Demo41mCustomAdapter adapter
                =new Demo41mCustomAdapter(context,R.layout.demo41_item_layout,list);
        listView.setAdapter(adapter);

    }
}