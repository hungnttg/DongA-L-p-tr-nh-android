package com.hungnq40.myapplication.demo4n;

public class Demo4nContact {
    private int color;
    private String name;
    private String phone;

    public Demo4nContact(int color, String name, String phone) {
        this.color = color;
        this.name = name;
        this.phone = phone;
    }

    public Demo4nContact() {
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
