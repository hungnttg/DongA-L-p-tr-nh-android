package com.hungnq40.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo52MainActivity extends AppCompatActivity {
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_main);
        listView=findViewById(R.id.demo52Listview);
        //B1- Tao layout
        //B2- Tao nguon du lieu
        List<HashMap<String,Object>> list=new ArrayList<>();//tao list
        HashMap<String,Object> hm=new HashMap<>();
        hm.put("ten","hung");
        hm.put("tuoi",20);
        hm.put("hinh",R.drawable.apple);
        list.add(hm);

        hm=new HashMap<>();
        hm.put("ten","An");
        hm.put("tuoi",21);
        hm.put("hinh",R.drawable.blogger);
        list.add(hm);

        hm=new HashMap<>();
        hm.put("ten","binh");
        hm.put("tuoi",18);
        hm.put("hinh",R.drawable.dell);
        list.add(hm);

        hm=new HashMap<>();
        hm.put("ten","Cong");
        hm.put("tuoi",22);
        hm.put("hinh",R.drawable.chrome);
        list.add(hm);
        //b3- Anh xa nguon du lieu
        String[] from = {"ten","tuoi","hinh"};
        int[] to = {R.id.demo52TxtTen,R.id.demo52TxtTuoi,R.id.demo52Img};
        //b4- Tao simple adapter
        SimpleAdapter simpleAdapter=new SimpleAdapter(this,list,R.layout.demo52_item_view,from,to);
        //b5- Dua du lieu len listview
        listView.setAdapter(simpleAdapter);

    }
}