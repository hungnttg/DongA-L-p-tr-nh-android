import React from "react";
import { StyleSheet,View,Text,TouchableOpacity } from "react-native";
export default class MTDT11 extends React.Component{
      //1. Khai bao bien
      constructor(props)
      {
         super(props);   
         //khai bao cac hang so
         this.operations=['DEL','+','-','*','/'];
         //khai bao cac bien (khai bao trong state)
         this.state={
            resultText: '', //bien luu tru ket qua
            calculationtext: '', //bien luu tru phep tinh
         };
      }
      //2.Khai bao ham
      //2.1 xu ly su kien khi click button
      pressButton(text)
      {
            if(text=="=")//khi click vao dau =
            {
                  //goi ham tinh toan ket qua
                  return this.calculationResult(this.state.resultText);
            }
            else //truowng hop khong phai dau =
            {
                  //noi chuoi
                  this.setState({
                        resultText: this.state.resultText+text,
                  });
            }
      }
      //2.2 viet ham tinh toan ket qua
      calculationResult(text)
      {
            //tinh toan ket qua
            this.setState({
                  calculationtext: eval(text),
            });
      }
      //2.3 Xu ly phep tinh
      operate(op)
      {
            switch(op)
            {
                  case 'DEL': //xoa ky tu
                        let text=this.state.resultText.split('');//chuoi->mang
                        text.pop();//xoa thanh phan cuoi cung cua mang
                        this.setState({
                              resultText: text.join(''),//mang -> chuoi
                        });
                        break;
                  case '+':
                  case '-':
                  case '*':
                  case '/':
                        this.setState({
                              resultText: this.state.resultText+op,//noi cac phep tinh
                        });
                        break;
                  
            }
      }
      //3. Tao giao dien
      render()
      {
            //3.1 Xu ly giao dien: number
            let rows=[];//mang chua cac dong
            let nums=[[1,2,3],[4,5,6],[7,8,9],['.','0','=']];
            for(let i=0;i<4;i++)//4 dong
            {
                  let row=[];//mang chua cac button
                  for(let j=0;j<3;j++)//3 cot
                  {
                    //dua button vao row
                    row.push(
                        <TouchableOpacity style={styles.rows} key={nums[i][j]}
                              onPress={()=>this.pressButton(nums[i][j])}>
                              <Text style={styles.textBtn} >{nums[i][j]}</Text>
                        </TouchableOpacity>
                    );          
                  }
                  //dua row vao rows
                  rows.push(
                        <View key={i}>{row}</View>
                  );
            }
            //3.2 xu ly giao dien cua phep tinh
            let ops=[];//mang chua phep tinh
            for(let i=0;i<5;i++)//co 5 dong trong 1 cot
            {
                  ops.push(
                        <TouchableOpacity style={styles.rows} key={this.operations[i]}
                        onPress={()=>this.operate(this.operations[i])}>
                              <Text style={styles.textBtn}>{this.operations[i]}</Text>
                        </TouchableOpacity>
                  );
            }
            
            return(
                  <View style={styles.container}>
                        <View style={styles.result}><Text style={styles.textBtn}>{this.state.resultText}</Text></View>
                        <View style={styles.caculation}><Text style={styles.textBtn}>{this.state.calculationtext}</Text></View>
                        <View style={styles.buttons}>
                              <View style={styles.numbers}>{rows}</View>
                              <View style={styles.operators}>{ops}</View>
                        </View>
                  </View>
            );
      }        

}
const styles= StyleSheet.create({
    container:{
          flex:1,//100%
          flexDirection:'column',
          backgroundColor:'pink',
    },
    result:{
          flex:1,//1/10
          alignItems:'flex-end',
          justifyContent:'space-around',
          backgroundColor:'yellow',
    },
    caculation:{
      flex:2,//2/10
      alignItems:'stretch',
      justifyContent:'space-around',
      backgroundColor:'green',
    },
    buttons:{
      flex:7,//chiem 7/10
      flexDirection:'row',
      backgroundColor:'#AAA1111',

    },
    numbers:{
      flex:3,//chiem 3/4 dong
      backgroundColor:'#AAA3333',
      justifyContent:'space-around',
      alignItems:'stretch',
      flexDirection:'row',
    },
    operators:{
      flex:1,//1/4 cua dong
      flexDirection:'column',
      backgroundColor:'#CCCC6666',
      justifyContent:'space-around',
      alignItems:'stretch',
    },    
    rows:{
      flexDirection:'row',
      flex:1,
      justifyContent:'space-around',
      alignItems:'stretch',
    } ,  
    textBtn:{
      fontSize:30,
      fontWeight:'bold',
    }
});