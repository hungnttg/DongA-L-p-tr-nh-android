package com.hungnq40.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Activity 1");
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);
        btn1=findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //tao intent
                Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                //dua du lieu vao intent
                intent.putExtra("so1",txt1.getText().toString());
                intent.putExtra("so2",txt2.getText().toString());
                //chuyen du lieu tu A sang B
                startActivity(intent);
            }
        });
    }


}