package com.hungnq40.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView tv1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("activity 2");
        tv1=findViewById(R.id.tv1);
        Intent intent=getIntent();//lay du lieu tu A chuyen sang
        //boc tach du lieu
        String dulieu1= intent.getStringExtra("so1");
        String dulieu2=intent.getStringExtra("so2");
        //chuyen du lieu sang so
        double so1=Double.parseDouble(dulieu1);
        double so2=Double.parseDouble(dulieu2);
        //tinh tong
        double tong=so1+so2;
        //hien thi ket qua cho nguoi dung
        tv1.setText(String.valueOf(tong));
    }
}