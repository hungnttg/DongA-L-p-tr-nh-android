﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;//thu vien ket noi csdl
using System.Data;
using System.Windows.Forms;

namespace DuAn
{
    public class KetNoiCSDL
    {
        SqlConnection conn;// doi tuong ket noi csdl
        SqlCommand com;//doi tuong xu ly lenh
        SqlDataAdapter da;//adapter truyen du lieu
        DataSet ds;//luu tru du lieu
        public void ketnoi()
        { 
            //chuoi ket noi csdl
            string sqlConnectString="Data Source=.;Initial Catalog=SachDB;Integrated Security=True";
            //tao ket noi
            conn = new SqlConnection(sqlConnectString);//tao ket noi
            da = new SqlDataAdapter();//tao adapter-> chuyen du lieu
            ds = new DataSet();//luu du lieu
        }
        public void getData(ListView lv)
        {
            com = new SqlCommand("SELECT * FROM Products", conn);//truyen cau lenh
            da.SelectCommand = com;//xac dinh cau lenh la select
            da.Fill(ds, "Products");//lay du lieu bang Product chuyen vao dataset
            //dua du lieu tu dataset len listview
            for (int rows = 0; rows < ds.Tables[0].Rows.Count; rows++)//dua vao vong lap
            { 
                //them tung dong vao listview
                lv.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());
                //them tung o vao dong
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());

            }


        }

    }
}
