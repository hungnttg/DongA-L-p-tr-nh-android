﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        DataSet ds;
        int selectedIndex;
        string operation;
        ProductsController pc;
        public Form1()
        {
            InitializeComponent();
            ds = new DataSet();
            pc = new ProductsController();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //xoa cac item trong listview
            lstView.Items.Clear();
            ds.Clear();//xoa du lieu trong dataset
            ds = pc.GetProducts();
            //lay du lieu tu dataset va dua vao listview
            for (int rows = 0; rows < pc.ds.Tables[0].Rows.Count; rows++)
            {
                //them vao 1 dong
                lstView.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());
                //add cot vao dong do
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());
            }
        }

        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            operation = "insert";
            txtMaSach.Focus();
            btnLuu.Enabled = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            operation = "update";
            //xac dinh id
            selectedIndex = lstView.SelectedItems[0].Index;
            //
            txtTieuDe.Focus();
            btnLuu.Enabled = true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (operation == "insert")//insert du lieu
            {
                Products p=new Products();
                p.ProductCode=txtMaSach.Text;
                p.Description=txtTieuDe.Text;
                p.UnitPrice=Convert.ToDouble(txtGia.Text);
                p.OnHandQuantity=Convert.ToInt32(txtSoLuong.Text);
                pc.AddProduct(p);
            }
            else if (operation == "update")
            {
                Products p = new Products();
                p.ProductCode = txtMaSach.Text;
                p.Description = txtTieuDe.Text;
                p.UnitPrice = Convert.ToDouble(txtGia.Text);
                p.OnHandQuantity = Convert.ToInt32(txtSoLuong.Text);
                pc.UpdateProduct(p, selectedIndex);
                
            }

            if (operation != "")
            {
                Form1_Load(null, null);//load form
            }
        }

        private void lstView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstView_Click(object sender, EventArgs e)
        {
            int index = lstView.SelectedItems[0].Index;//xac dinh chi so
            DataRow dr = ds.Tables["Products"].Rows[index];//lay dong tuong ung
            txtMaSach.Text = dr[0].ToString();//dien du lieu vao truong ma sach
            txtTieuDe.Text = dr[1].ToString();
            txtGia.Text = dr[2].ToString();
            txtSoLuong.Text = dr[3].ToString();
            btnLuu.Enabled = true;
        }
    }
}
