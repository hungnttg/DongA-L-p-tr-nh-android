﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    public class Products
    {

        public Products() { }
        public string ProductCode { get; set; }
        public string Description { get; set; }
        public double UnitPrice { get; set; }
        public int OnHandQuantity { get; set; }
    }
}
