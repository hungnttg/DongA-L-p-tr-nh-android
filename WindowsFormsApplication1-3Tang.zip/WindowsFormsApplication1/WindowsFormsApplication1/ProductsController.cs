﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace WindowsFormsApplication1
{
    public  class ProductsController
    {
        public DataSet ds;
        public SqlDataAdapter da;
       //ham ket noi
        public SqlConnection GetConnection()
        {
            string sqlString = "Data Source=.; Initial Catalog=SachDB; Integrated Security=true;";
            SqlConnection conn = new SqlConnection(sqlString);
            return conn;
           
        }
        //ham list tat ca cac san pham
        public DataSet GetProducts()
        {
            SqlConnection conn = GetConnection();
            SqlCommand com = new SqlCommand("select * from Products", conn);
            da = new SqlDataAdapter();
            //khoi tao bo dem du lieu
            ds = new DataSet();
            da.SelectCommand = com;
            //dien du lieu tu adapter vao dataset
            da.Fill(ds, "Products");
            return ds;
        }
        //ham them du lieu
        public void AddProduct(Products p)
        {
            //lay du lieu nguoid dung nhap va them vao 1 dong trong dataset
            ds.Tables["products"].Rows.Add(p.ProductCode, p.Description,
                p.UnitPrice, p.OnHandQuantity);
            //chuan bi cap nhat vao database
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            cb.GetInsertCommand();//thuc hien insert
            //update vao dataset
            da.Update(ds, "Products");
        }
        //ham sua san pham
        public void UpdateProduct(Products p, int selectedIndex)
        {
            //cap nhat tieu de vao dataset
            ds.Tables["products"].Rows[selectedIndex][1] = p.Description;
            //cap nhat gia vao dataset
            ds.Tables["products"].Rows[selectedIndex][2] = p.UnitPrice;
            //cap nhat so luong vao dataset
            ds.Tables["products"].Rows[selectedIndex][3] = p.OnHandQuantity;
            //chuan bi cap nhat du lieu tu dataset vao database
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            //thuc hien update
            cb.GetUpdateCommand();
            //update vao dataset de cap nhat len listview
            da.Update(ds, "Products");
        }
        //ham xoa san pham
        public void DeleteProduct(int index)
        {
            //xac dinh id
            //xoa trong dataset
            ds.Tables["Products"].Rows[index].Delete();
            //chuan bi xoa trong database
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            cb.GetDeleteCommand();//thuc hien xoa trong database
            da.Update(ds, "Products");//cap nhat vao dataset
            //load form
        }
    }
}
