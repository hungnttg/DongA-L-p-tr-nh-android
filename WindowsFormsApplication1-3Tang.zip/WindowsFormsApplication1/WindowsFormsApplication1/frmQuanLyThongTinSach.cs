﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyThongTinSach
{
    public partial class frmQuanLyThongTinSach : Form
    {
        //Khai bao cac bien
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        string operation;
        int selectedIndex;

        public frmQuanLyThongTinSach()
        {
            InitializeComponent();
            //khoi tao ket noi csdl
            string sqlString="Data Source=.; Initial Catalog=SachDB; Integrated Security=true;";
            conn = new SqlConnection(sqlString);
            //khoi tao adapter
            da = new SqlDataAdapter();
            //khoi tao bo dem du lieu
            ds = new DataSet();
           
        }

        private void frmQuanLyThongTinSach_Load(object sender, EventArgs e)
        {
            //xoa cac item trong listview
            lstView.Items.Clear();
            ds.Clear();//xoa du lieu trong dataset
            //
            //khoi tao lenh
            com = new SqlCommand("select * from Products",conn);
            //tryen lenh vao adapter
            da.SelectCommand = com;
            //dien du lieu tu adapter vao dataset
            da.Fill(ds, "Products");
            //lay du lieu tu dataset va dua vao listview
            for (int rows = 0; rows < ds.Tables[0].Rows.Count; rows++)
            {
                //them vao 1 dong
                lstView.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());
                //add cot vao dong do
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lstView.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());
            }


        }

        // Thêm một bản ghi mới
        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            operation = "insert";
            txtMaSach.Focus();
            btnLuu.Enabled = true;
        }

        // Sửa một bản ghi
        private void btnSua_Click(object sender, EventArgs e)
        {
            operation = "update";
            //xac dinh id
            selectedIndex = lstView.SelectedItems[0].Index;
            //
            txtTieuDe.Focus();
            btnLuu.Enabled = true;
        }

        // Lưu lại tác vụ thêm mới hoặc sửa
        private void btnLuu_Click(object sender, EventArgs e)
        {
            
            if (operation == "insert")//insert du lieu
            {
                //lay du lieu nguoid dung nhap va them vao 1 dong trong dataset
                ds.Tables["products"].Rows.Add(txtMaSach.Text,txtTieuDe.Text,
                    Convert.ToDecimal(txtGia.Text),Convert.ToInt32(txtSoLuong.Text));
                //chuan bi cap nhat vao database
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                cb.GetInsertCommand();//thuc hien insert
                //update vao dataset
                da.Update(ds,"Products");
            }
            else if (operation == "update")
            {
                //cap nhat tieu de vao dataset
                ds.Tables["products"].Rows[selectedIndex][1] = txtTieuDe.Text;
                //cap nhat gia vao dataset
                ds.Tables["products"].Rows[selectedIndex][2] = txtGia.Text;
                //cap nhat so luong vao dataset
                ds.Tables["products"].Rows[selectedIndex][3] = txtSoLuong.Text;
                //chuan bi cap nhat du lieu tu dataset vao database
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                //thuc hien update
                cb.GetUpdateCommand();
                //update vao dataset de cap nhat len listview
                da.Update(ds,"Products");
            }
            
            if (operation != "")
            {
                frmQuanLyThongTinSach_Load(null, null);//load form
            }


           
        }

        // Xóa bản ghi được chọn
        private void btnXoa_Click(object sender, EventArgs e)
        {
            //xac dinh id
            int index = lstView.SelectedItems[0].Index;
            //xoa trong dataset
            ds.Tables["Products"].Rows[index].Delete();
            //chuan bi xoa trong database
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            cb.GetDeleteCommand();//thuc hien xoa trong database
            da.Update(ds,"Products");//cap nhat vao dataset
            //load form
            frmQuanLyThongTinSach_Load(null, null);//load form
        }

        // Xóa nội dung trên các TextBox
        void ClearControls()
        { 
            
        }
           

        // Bỏ qua tác vụ đang thực hiện
        private void btnBoQua_Click(object sender, EventArgs e)
        {
          
        }

        //Tìm một bản ghi từ dataset
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
          
        }

        private void lstView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Hiển thị lên textbox bản ghi vừa được chọn
        private void lstView_Click(object sender, EventArgs e)
        {
            int index = lstView.SelectedItems[0].Index;//xac dinh chi so
            DataRow dr = ds.Tables["Products"].Rows[index];//lay dong tuong ung
            txtMaSach.Text = dr[0].ToString();//dien du lieu vao truong ma sach
            txtTieuDe.Text = dr[1].ToString();
            txtGia.Text = dr[2].ToString();
            txtSoLuong.Text = dr[3].ToString();
            btnLuu.Enabled = true;
        }

        // Vô hiệu quá các textbox
        void DisableControls()
        {
           
        }

        // Kích hoạt các textbox
        void EnableControls()
        {
           
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {

        }

    }
}
