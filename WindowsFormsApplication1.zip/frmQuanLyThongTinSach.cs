﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyThongTinSach
{
    public partial class frmQuanLyThongTinSach : Form
    {
        

        public frmQuanLyThongTinSach()
        {
            InitializeComponent();
           
        }

        private void frmQuanLyThongTinSach_Load(object sender, EventArgs e)
        {
            

        }

        // Thêm một bản ghi mới
        private void btnThemMoi_Click(object sender, EventArgs e)
        {
           
        }

        // Sửa một bản ghi
        private void btnSua_Click(object sender, EventArgs e)
        {
           
        }

        // Lưu lại tác vụ thêm mới hoặc sửa
        private void btnLuu_Click(object sender, EventArgs e)
        {
           

           
        }

        // Xóa bản ghi được chọn
        private void btnXoa_Click(object sender, EventArgs e)
        {

        }

        // Xóa nội dung trên các TextBox
        void ClearControls()
        {
           

        // Bỏ qua tác vụ đang thực hiện
        private void btnBoQua_Click(object sender, EventArgs e)
        {
          
        }

        //Tìm một bản ghi từ dataset
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
          
        }

        private void lstView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Hiển thị lên textbox bản ghi vừa được chọn
        private void lstView_Click(object sender, EventArgs e)
        {
           
        }

        // Vô hiệu quá các textbox
        void DisableControls()
        {
           
        }

        // Kích hoạt các textbox
        void EnableControls()
        {
           
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {

        }

    }
}
