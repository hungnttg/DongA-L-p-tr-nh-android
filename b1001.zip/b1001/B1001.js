import React from "react";
import { Text,View,TouchableOpacity,StyleSheet } from "react-native";
export default class B1001 extends React.Component{
     //1. Vung khai bao bien va trang thai
     constructor(props)
     {
          super(props);
          this.state={
               resultText:"",//hien thi ket qua tinh toan
               calculationText:"",//hien thi phep tinh
          };
     }
     //2. vung dinh nghia ham
     //2.1. Ham tinh toan ket qua
     _hamTinhToanKetQua(text)
     {
          this.setState({//thay doi trang thai
               resultText: eval(text),
          });
     }
     //2.2. Ham nhan button
     _pressButton(text)
     {
          if(text=="=")//khi nhan vao dau =
          {
               return this._hamTinhToanKetQua(this.state.calculationText);
          }
          else//cac truong hop khac dau =
          {
               //noi chuoi
               this.setState({
                    calculationText: this.state.calculationText+text,//noi chuoi
               });
          }
     }

     //2.3. Xu ly key qua tinh toan: (khi nhan vao +,-,*,/,DEL)
     _hamXuLyCongTruNhanChiaDEL(phepTinh)
     {
          switch(phepTinh)
          {
               case 'DEL':
                    //B1- pha vo chuoi: split
                    let text=this.state.calculationText.split('');
                    //b2- xoa phan tu cuoi: pop
                    text.pop();
                    //b3- noi chuoi: join
                    this.setState({
                         calculationText: text.join(''),
                    });
                    break;
               case '+':
               case '-':
               case '*':
               case '/':
                    //noi chuoi
                    this.setState({
                         calculationText: this.state.calculationText+phepTinh,
                    });
                    break;
          }
     }
     //3. Vung thiet ke giao dien
     render()
     {
          //Vi tri xu ly vong lap giao dien
          //1.Tao cac button
          let rows=[];//khai bao cac dong
          let nums=[[1,2,3],[4,5,6],[7,8,9],['.','0','=']];//khai bao cac so de dien vao cac dong
          for(let i=0;i<4;i++)//so dong
          {
               let row=[];//1 dong chua cac con so
               for(let j=0;j<3;j++)
               {
                    //dua cac button vao cac o
                    row.push(
                         <TouchableOpacity style={styles.btn} key={nums[i][j]}
                              onPress={()=>this._pressButton(nums[i][j])}
                         >
                              <Text style={styles.textBtn}>{nums[i][j]}</Text>          
                         </TouchableOpacity>
                    );
               }
               //dua row vao mang rows
               rows.push(
                    <View style={styles.row} key={i}>{row}</View>
               );
          }
          //2.Tao cac phep tinh
          let ops=[];//mang cac phep tinh
          let operator=['+','-','*','/','DEL'];
          for(let i=0;i<5;i++)
          {
               ops.push(
                    <TouchableOpacity style={styles.btn} key={operator[i]}
                         onPress={()=>this._hamXuLyCongTruNhanChiaDEL(operator[i])}
                    >
                         <Text style={styles.textBtn}>{operator[i]}</Text>
                    </TouchableOpacity>
               );
          }
          //-------------------------------
          return(
               <View style={styles.container}>
                    <View style={styles.result}>
                         <Text style={styles.textBtn}>
                              {this.state.resultText}
                         </Text>
                    </View>
                    <View style={styles.calculation}>
                    <Text style={styles.textBtn}>
                              {this.state.calculationText}
                         </Text>
                    </View>
                    <View style={styles.button}>
                         <View style={styles.numbers}>{rows}</View>
                         <View style={styles.operator}>{ops}</View>
                    </View>
               </View>
          );
     }
}
const styles=StyleSheet.create({
     container:{
          flex:1,//chiem 100%
          flexDirection:'column',
     },
     result:{
          flex:1, //1 phan 10
          backgroundColor:'blue',
          alignItems:'stretch',
          justifyContent:'space-around',
     },
     calculation:{
          flex:2, //2 phan 10
          backgroundColor:'green',
          alignItems:'stretch',
          justifyContent:'space-around',
     },
     button:{
          flex:7, //2 phan 10
          backgroundColor:'pink',
          flexDirection:'row',
     },
     numbers:{
          flex:3,//chiem 3/4
          backgroundColor:'#AAA111',
          justifyContent:'space-around',
          alignItems:'stretch',
         
     },
     operator:{
          flex:1,//chiem 3/4
          backgroundColor:'#CCC999',
          justifyContent:'space-around',
          alignItems:'stretch',
     },
     textBtn:{
          fontSize:30,
          fontWeight:'bold',
     },
     btn:{
          flex:1,
          justifyContent:'center',
          alignItems:'center',
     },
     row:{
          flexDirection:'row',
          flex:1,
     },

});