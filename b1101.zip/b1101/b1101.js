//1. Import thu vien
import React,{useState} from "react";
import { View,Text,StyleSheet,TouchableOpacity} from "react-native";
//2. Khai bao bien toan cuc
global.myVar="";
//3. Dinh nghia ham
export default function B1101(){
//3.1. Khai bao bien, thuoc tinh
//Co 2 thuoc tinh can cap nhat moi khi click: phepTinh, ketQua
//3.1.1. Khai bao Thuoc tinh phepTinh, ketQua
const [phepTinh, setPhepTinh]=useState('pheptinh');
const [ketQua,setKetQua]=useState('ketqua');
//3.1.2. Khai bao cac bien
let result="";
let calculation="";
//3.2. Dinh nghia ham
//3.2.1. Dinh nghia ham pressButton
const pressButton =(text) =>
{
     if(text=="=")//khi nhan dau =
     {
          calculation=global.myVar;//nhan gia tri tu bien toan cuc
          return calculationResult(calculation);
     }
     else//khi click cac button khac
     {
          //noi chuoi
          calculation=global.myVar;//nhan gia tri tu bien toan cuc
          calculation=calculation+text;//noi chuoi
          global.myVar=calculation;//cap nhat len bien global
          //cap nhat gia tri moi vao bien calculation
          //sau khi goi setPhepTinh thi calculation se bi xoa
          //nhung da duoc cap nhat vao bien toan cuc
          setPhepTinh(calculation);
     }
}
//3.2.2 Dinh nghia ham tinh gia tri cua bieu thuc
const calculationResult=(text)=>
{
     result=eval(text);//tinh toan va tra ve result
     global.myVar="";//xoa bien toan cuc
     setKetQua(result);
}
//3.2.3. Dinh nghia ham xu ly khi click vao cac pheo tinh
const operate = (op)=>
{
     switch(op)
     {
          case 'DEL':
               let text=calculation.split('');//pha vo chuoi
               global.myVar=calculation;
               text.pop();//xoa thanh phan cuoi cung trong chuoi
               global.myVar=text;
               calculation=text.join('');//hop cac chuoi
               calculation=global.myVar;
               setPhepTinh(calculation);
               break;
          case '+':
          case '-':
          case '*':
          case '/':
               calculation=global.myVar;//lay gia tri tu bien toan cuc
               calculation=calculation+op;//noi chuoi
               global.myVar=calculation;//cap nhat len bien toan cuc
               //cap nhat vao thuoc tinh phep tinh
               setPhepTinh(calculation);
               break;
     }

}
//3.3 Thiet ke giao dien
//Thiet ke giao dien su dung vong lap
     //P1-Thiet ke cac number button
   
let rows=[];//khai bao mang cac dong
let nums=[[1,2,3],[4,5,6],[7,8,9],['.','0','=']];
for(let i=0;i<4;i++)//4 dong i
{
     let row=[];//mang dong
     for(let j=0;j<3;j++)
     {
          //dua cac con so vao dong
          row.push(
               <TouchableOpacity style={styles.btn} key={nums[i][j]}
                    onPress={()=>pressButton(nums[i][j])}
               >
                    <Text>{nums[i][j]}</Text>
               </TouchableOpacity>
          );
     }
     //dua row vao rows
     rows.push(
          <View key={i} style={styles.row}>{row}</View>
     );
}
  //P2-Thiet ke cac operator button
  let ops=[];
  let operator=['+','-','*','/','DEL'];
  for(let i=0;i<5;i++)
  {
     ops.push(
          <TouchableOpacity
               key={operator[i]} style={styles.btn}
               onPress={()=>operate(operator[i])}
          >
               {operator[i]}
          </TouchableOpacity>
     );
  }
return(
     
     <View style={styles.container}>
          <View style={styles.resultText}>
               <Text style={styles.textCSS}>{ketQua}</Text>
          </View>
          <View style={styles.calculationText}>
               <Text style={styles.textCSS}>{phepTinh}</Text>
          </View>
          <View style={styles.butttons}>
               <View style={styles.numbersButtons}>{rows}</View>
               <View style={styles.operationButtons}>{ops}</View>
          </View>
     </View>
);

}
//4. Dinh nghia css
const styles=StyleSheet.create({
     container:{
          flex:1,
          flexDirection:'column',
          backgroundColor:'yellow',
     },
     resultText:{
          flex:1,
          backgroundColor:'green',
          justifyContent:'space-around',
          alignItems:'center',
     },
     calculationText:{
          flex:2,
          backgroundColor:'#AAA1111',
          justifyContent:'space-around',
          alignItems:'center',
     },
     butttons:{
          flex:7,
          backgroundColor:'pink',
          flexDirection:'row',
     },
     numbersButtons:{
          flex:3,
          backgroundColor:'#AAA1111',
          justifyContent:'space-around',
          alignItems:'stretch',
     },
     operationButtons:{
          flex:1,
          backgroundColor:'grey',
          justifyContent:'space-around',
          alignItems:'stretch',
     
     },
     btn:{
          flex:1,
          justifyContent:'center',
          alignItems:'center',
          fontSize:30,
          fontWeight:'bold',
     },
     row:{
          flex:1,
          flexDirection:'row',
          justifyContent:'space-around',
          alignItems:'stretch',
          fontSize:30,
          fontWeight:'bold',
     },
     textCSS:{
          fontSize:30,
          fontWeight:'bold',
     },
});