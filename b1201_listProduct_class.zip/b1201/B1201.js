//import thu vien
import React from "react";
import { FlatList } from "react-native";
import Product1201 from "./ProductB1201";
export default class ListProduct1201 extends React.Component{
     //1.khai bao bien, state trong Constructor
     constructor()
     {
          super();
          this.state={
               products: null,
          };
          //khoi tao cac ham
          this.getProducts=this.getProducts.bind(this);
          this.renderItem=this.renderItem.bind(this);
          
     }
     //goi ham load du lieu (tuong duong voi onCreate trong AndroidStudio)
     componentDidMount(){
          this.getProducts();
     }
     //2. Dinh nghia cac ham
     //2.1 Dinh nghia ham lay du lieu
     async getProducts()
     {
          const url='https://hungnttg.github.io/shopgiay.json';//link du lieu
          let response= await fetch(url,{method:'GET'});//phuong thuc lay du lieu
          let responseJSON= await response.json();//chuyen du lieu ve dang json
          //cap nhat vao state
          this.setState({
               products: responseJSON.products,
          });
     }
     //2.2. tao view
     renderItem({item})
     {
          return(
               <Product1201
                    dataProd={item}
               />
          );
     }
     
     //3.Hien thi du lieu
     render()
     {
          return(
               <FlatList
                    data={this.state.products}
                    renderItem={this.renderItem}
                    numColumns={3}
                    removeClippedSubviews
               />
          );
     }
}