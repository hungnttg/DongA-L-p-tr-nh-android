//import thu vien
import React from "react";
import {View,Text,Image,StyleSheet,TouchableWithoutFeedback} from 'react-native';
//dinh nghia model
export default class Product1201 extends React.Component{
     constructor()
     {
          super();
          this.props= {
               dataProd: {},
               };
     }
     render()
     {
          //2. view
          return(
               <View style={styles.container}>
                    <TouchableWithoutFeedback>
                         <View>
                              <Image source={{uri:this.props.dataProd.search_image}} style={styles.image}/>
                              <Text>{this.props.dataProd.brands_filter_facet}</Text>
                              <Text>{this.props.dataProd.price}</Text>
                              <Text>{this.props.dataProd.dataProd}</Text>
                         </View>
                    </TouchableWithoutFeedback>
               </View>
               );
     }
}

    
//dinh nghia CSS
const styles=StyleSheet.create({
     container:{
          flex:1,
     },
     image:{
          width:200,
          height:200,
          borderWidth:1,
     },
});