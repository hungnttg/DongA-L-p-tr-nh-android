import React from "react";
import { FlatList, Text,View,Image,TouchableWithoutFeedback,StyleSheet } from "react-native";
import ProductB1301 from "./ProductB1301";

export default class ListProductB1301 extends React.Component{
     //1.Khoi tao du lieu
     constructor(props)
     {
          super(props);
          //khoi tao bien
          this.state={products: null,};
          //dinh nghia su kien
          this.layDuLieu=this.layDuLieu.bind(this);
          this.ketXuatHinhAnh=this.ketXuatHinhAnh.bind(this);
     }
     //2. Dinh nghia ham
     //ham OnCreate (khoi tao du lieu)
     componentDidMount()
     {
          this.layDuLieu();
     }
     async layDuLieu()
     {
          const url='https://hungnttg.github.io/shopgiay.json';
          let response=await fetch(url,{method:'GET'});//doc du lieu bang GET
          let resonseJSON= await response.json();//chuyen ve dang json
          //cap nhat vao bien khoi tao
          this.setState({
               products: resonseJSON.products, //ten bang du lieu la products
          });
     }
     //Dinh nghia ham ketXuatHinhAnh
     ketXuatHinhAnh({item})
     {
          return(
               <ProductB1301
                    dataProd={item}
               />
          );
     }
     //3. Tao giao dien
     render()
     {
          return(
               <FlatList
                    data={this.state.products}
                    renderItem={this.ketXuatHinhAnh}
                    numColumns={3}
                    removeClippedSubviews
               />
          );
     }
}