//1.import thu vien
import React from "react";
import { Text,View,Image,TouchableWithoutFeedback,StyleSheet } from "react-native";
//2. Dinh nghia function
const ProductB1301 = (props) =>{
     //2.1. Props (Dinh nghia cacs thuoc tinh)
     const {
          dataProd={},
     }=props;
     //2.2 View du lieu (get, set)
     return(
          <View style={styles.container}>
               <TouchableWithoutFeedback>
                    <View>
                         <Image source={{uri:dataProd.search_image}} style={styles.image}/>
                         <Text>{dataProd.brands_filter_facet}</Text>
                         <Text>{dataProd.price}</Text>
                         <Text>{dataProd.product_additional_info}</Text>
                    </View>
               </TouchableWithoutFeedback>
          </View>
     );
}
export default ProductB1301;
//dinh dang
const styles=StyleSheet.create({
     container:{
          flex:1,
     },
     image:{
          width:200,
          height:200,
          borderWidth:1,
     },
});